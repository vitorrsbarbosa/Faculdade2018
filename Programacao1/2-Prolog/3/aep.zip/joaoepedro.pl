%pessoa(animal).

ee(joao,passaro).
ee(pedro,peixe).
ee(maria,minhoca).
ee(chucknorris,gato).

%gosta(primeiro,segundo).

gosta(passaro,minhoca).
gosta(gato,peixe).
gosta(gato,passaro).

come(X,Y):-gosta(_,Y),ee(Y,X).
