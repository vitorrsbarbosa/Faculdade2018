 %marcas(ID,NOMEDAMARCA).
 
 marcas('VW','Volkswagem').
 marcas('Ford','Ford').
 marcas('GM','General Motors').
 marcas('Fiat','Fiat').
 marcas('Renault','Renault').
 marcas('MB','Mercedes Bens').
 
 %carros(ID,MODELO,ANO,COR).
 
 carros('VW','Fox',2005,'preto').
 carros('VW','Fox',2008,'preto').
 carros('Ford','Ecosport',2009,'verde').
 carros('Ford','KA',2008,'prata').
 carros('Fiat','Punto',2008,'branco').
 carros('Fiat','Uno',2007,'preto').
 carros('Fiat','Uno',2005,'prata').
 carros('Fiat','Stilo',2008,'verde').
 carros('Fiat','Uno',2009,'branco').
 carros('Peugeot','207',2010,'prata').
 carros('Peugeot','207',2010,'prata').
 carros('Peugeot','207',2007,'azul').
 carros('Chrysler','300 C',2008,'verde').
 carros('Fiat','Stilo',200,'4prata').
 
 
 %marcacarro(ID,MODELO):-marcas(ID,NOMEDAMARCA),carros(ID,MODELO,ANO,COR).
 
 marcacarro(ID,NOME,MODELO,ANO,COR):-marcas(ID,NOME),carros(ID,MODELO,ANO,COR).
 