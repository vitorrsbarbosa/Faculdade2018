#include "tipos.h"

int main(){
	TLista lista;
	inicializarLista(&lista);
	char menu;
	do{
		printf("Informe uma opcao :");
		printf("\n 1- Insercao");
		printf("\n 2- Consulta");
		printf("\n 3- Exclusao");
		printf("\n 4- Relatorio");
		printf("\n 0- Sair\n");
		scanf("%c",&menu);
		fflush(stdin);
		
	
		switch(menu){
			case '1': inserir(&lista);break;
			case '2': mostraLista(&lista);break;
			case '3': excluir(&lista);break;
			case '4': geraRelatorio(&lista);break;
		}

		system("cls");
		
	}while(menu != '0');
	
	
	
	system("pause");
	return 0;
}
