#include "tipos.h"
void excluir(TLista *p){
	char busca[50];
	printf("Informe o nome que deseja excluir :");
	gets(busca);
	
	int x;
	for(x=0 ; x<=p->tamanho; x++){
		if(strcmp(p->aluno[x].nome,busca) == 0){
			break;
		}
	}
	if(x == p->tamanho){
		printf("Pessoa n�o encontrada");
	}
	else{
		for(int j=x; j<p->tamanho; j++){
			p->aluno[j] = p->aluno[j+1];
		}
		p->tamanho--;
	}
}
