#include "tipos.h"
void geraRelatorio(TLista *p){
	
	char menu;
	printf("Informe o tipo de relatorio :");
	printf("\n 1- Por Nome");
	printf("\n 2- Por Ra");
	printf("\n 3- Por Media\n");
	scanf("%c",&menu);
	
	switch(menu){
		case '1': organizaLista(p, 1);break;
		case '2': organizaLista(p, 2);break;
		case '3': organizaLista(p, 3);break;
	}
}
