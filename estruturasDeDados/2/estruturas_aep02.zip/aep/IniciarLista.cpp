#include "tipos.h"

void inicializarLista(TLista *p){
	p->tamanho = 0;
}
