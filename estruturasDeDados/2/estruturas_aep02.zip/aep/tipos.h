#ifndef _tipos_
#define _tipos_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

typedef struct TipoAluno{
	char ra[20] , nome[50];
	float nota[4] , media;
}TAluno;

typedef struct TipoLista{
	TAluno aluno[100];
	int tamanho;
}TLista;

void inicializarLista(TLista *p);
void inserirOrdenado(TLista *p, TAluno novoAluno,int tipoOrdem);
void inserir(TLista *p);
void mostraLista(TLista *p);
void organizaLista(TLista *p, int tipoOrganizacao);
void geraRelatorio(TLista *p);
void excluir(TLista *p);

#endif
