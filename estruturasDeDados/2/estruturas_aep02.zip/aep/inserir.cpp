#include "tipos.h"
void inserir(TLista *p){
	TAluno novoAluno;
	
	printf("Informe o Ra    :");
	gets(novoAluno.ra);
	printf("Informe o nome  :");
	gets(novoAluno.nome);
	printf("Informe a nota 1:");
	scanf("%f",&novoAluno.nota[0]);
	fflush(stdin);
	printf("Informe o nome 2:");
	scanf("%f",&novoAluno.nota[1]);
	fflush(stdin);
	printf("Informe o nome 3:");
	scanf("%f",&novoAluno.nota[2]);
	fflush(stdin);
	printf("Informe o nome 4:");
	scanf("%f",&novoAluno.nota[3]);
	fflush(stdin);
	novoAluno.media = (novoAluno.nota[0] + novoAluno.nota[1] + novoAluno.nota[2] + novoAluno.nota[3])/4;
	inserirOrdenado(p, novoAluno, 1);
}
