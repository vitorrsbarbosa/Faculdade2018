#include "tipos.h"
void organizaLista(TLista *p, int tipoOrganizacao){
	TLista listaAux;
	inicializarLista(&listaAux);
	
	for(int x=0 ; x< p->tamanho ; x++){
		inserirOrdenado(&listaAux,p->aluno[x],tipoOrganizacao);
	}
	
	mostraLista(&listaAux);
	
}
