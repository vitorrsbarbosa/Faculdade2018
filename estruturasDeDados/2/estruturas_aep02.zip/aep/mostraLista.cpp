#include "tipos.h"

void mostraLista(TLista *p){
	if(p->tamanho > 0){
		for(int x=0; x<p->tamanho; x++){
			printf("Ra    = %s\n",p->aluno[x].ra);
			printf("Nome  = %s\n",p->aluno[x].nome);
			printf("Nota 1= %.2f\n",p->aluno[x].nota[0]);
			printf("Nota 2= %.2f\n",p->aluno[x].nota[1]);
			printf("Nota 3= %.2f\n",p->aluno[x].nota[2]);
			printf("Nota 4= %.2f\n",p->aluno[x].nota[3]);
			printf("Media = %2.f\n",p->aluno[x].media);
			getch();
			system("cls");
		}
	}else{
		printf("Lista Vazia !!");
		getch();
	}
	
}
