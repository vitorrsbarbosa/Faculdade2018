#include "tipos.h"

void inserirOrdenado(TLista *p, TAluno novoAluno,int tipoOrdem){
	/*
	1-Nome
	2-Ra
	3-Media
	*/
	bool condicao;
	if(p->tamanho!= 0){
	
		switch(tipoOrdem){
			case 1:
				if(strcmp(p->aluno[p->tamanho-1].nome, novoAluno.nome) == -1){
					condicao = true;
				}
				else{
					condicao = false;
				}
			break;
				
			case 2:
				if(strcmp(p->aluno[p->tamanho-1].ra, novoAluno.ra) == -1){
					condicao = true;
				}
				else{
					condicao = false;
				}
			break;
				
			case 3:
				if(p->aluno[p->tamanho-1].media > novoAluno.media){
					condicao = true;
				}
				else{
					condicao = false;
				}
			break;
		}
	}
	
	
	
	if(p->tamanho == 0){
		p->aluno[0] = novoAluno;
	}
	else{
		if(condicao){
			p->aluno[p->tamanho] = novoAluno;
		}
		else{
			int i;
			
//-----------------------------------------------------------------------------------------//
			switch(tipoOrdem){
				case 1:
					for(i=0; i<p->tamanho; i++){
						if(strcmp(p->aluno[i].nome, novoAluno.nome) == 1){
							break;
						}
					}
				break;
					
				case 2:
					for(i=0; i<p->tamanho; i++){
						if(strcmp(p->aluno[i].ra, novoAluno.ra) == 1){
							break;
						}
					}
				break;
					
				case 3:
					for(i=0; i<p->tamanho; i++){
						if(p->aluno[i].media < novoAluno.media){
							break;
						}
					}
				break;
//-----------------------------------------------------------------------------------------//

			}
			for(int j = p->tamanho; j>i; j--){
				p->aluno[j] = p->aluno[j-1];	
			}

			p->aluno[i] = novoAluno;
		}
	}
	
	p->tamanho++;
	
}
